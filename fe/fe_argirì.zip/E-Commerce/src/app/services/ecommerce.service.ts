import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Paths } from '../enums/ecommerce.enum';
import { Category, Seller, Product, Customer, CreditCard, ProductInformation, OrderDetail, Order, ReturnDetail, Return } from '../interfaces/ecommerce.interface';

@Injectable({
  providedIn: 'root'
})
export class ECommerceService {

  constructor(private http: HttpClient) { }
  nameToSearch = "";
  category!: Category;
  product!: Product;
  productDetails!: ProductInformation;
  paymentMethod!: string;
  basketProducts: ProductInformation[] = [];
  authenticatedCustomer: Customer | null = null;
  productsToOrder: ProductInformation[] = [];
  loading: boolean = false;
  fromSignIn = false;
  isAdministrator = false;
  fromSearch = false;

  setFromSearch(value: boolean){
    this.fromSearch = value;
  }

  setPaymentMethod(value: string){
    this.paymentMethod = value;
  }

  setFromSignIn(value: boolean){
    this.fromSignIn = value;
  }

  setAuthenticatedCustomer(customer: Customer){
    this.authenticatedCustomer = customer;
    if(customer.email == "admin@admin")
      this.isAdministrator = true;
    else
      this.isAdministrator = false;
  }

  addProductToBasket(productToAdd: Product, quantity: number){
    let isPresent = false;
    this.basketProducts.forEach(product =>{
      if(product.product == productToAdd){
        product.quantity = product.quantity + quantity;
        isPresent = true;
      }
    })
    if(!isPresent){
      this.basketProducts.push({product: productToAdd, quantity: quantity, showOption: false, options: []});
    }
  }

  deleteProductFromBasket(productToDelete: ProductInformation){
    let index = this.basketProducts.indexOf(productToDelete);
    this.basketProducts.splice(index, 1);
  }

  setCategory(category: Category){
    this.category = category;
  }

  setProduct(product: Product){
    this.product = product;
  }

  setProductDetails(product: Product, quantity: number){
    const productToAdd: ProductInformation = {
      product: product,
      quantity: quantity,
      showOption: false,
      options: []
    }
    this.productDetails = productToAdd;
  }

  getProduct(){
    return this.product;
  }

  getSellers(): Observable<Seller[]> {
    return this.http.get<Seller[]>(`${Paths.main}${Paths.sellers}`);
  }

  getCategories(): Observable<Category[]> {
    return this.http.get<Category[]>(`${Paths.main}${Paths.categories}`);
  }

  getSellerById(id: number): Observable<Seller>{
    return this.http.get<Seller>(Paths.main+Paths.sellerById+id);
  }

  getCategoryById(id: number): Observable<Category>{
    return this.http.get<Category>(Paths.main+Paths.categoryById+id);
  }

  addProduct(product: Product): Observable<any>{
    return this.http.post<any>(`${Paths.main}${Paths.addProduct}`, product);
  }

  addCategory(category: Category): Observable<any>{
    return this.http.post<any>(Paths.main+Paths.addCategory, category);
  }

  getAllProducts(): Observable<Product[]>{
    return this.http.get<Product[]>(Paths.main+Paths.products);
  }

  getAllProductsByCategory(): Observable<Product[]>{
    const params = new HttpParams()
    .set('id', this.category.id);
    return this.http.get<Product[]>(Paths.main+Paths.productsByCategory, {params});
  }

  getAllProductsByName(): Observable<Product[]>{
    const params = new HttpParams()
    .set('name', this.nameToSearch);
    return this.http.get<Product[]>(Paths.main+Paths.productsByName, {params});
  }

  addCustomer(customer: Customer): Observable<any>{
    return this.http.post<any>(Paths.main+Paths.addCustomer, customer);
  }

  authentication(email: string, password: string): Observable<Customer>{
    const params = new HttpParams()
    .set('email', email)
    .set('password', password);

    return this.http.get<Customer>(Paths.main+Paths.getCustomerForAuthentication, {params})
  }

  getCreditCardByCustomer(): Observable<CreditCard>{
    const params = new HttpParams()
    .set('id', this.authenticatedCustomer!.id)
    return this.http.get<CreditCard>(Paths.main+Paths.getCreditCardByCustomerId, {params})
  }

  addCreditCard(creditCard: CreditCard): Observable<any>{
    creditCard.customer = this.authenticatedCustomer!;
    return this.http.post<any>(Paths.main+Paths.addCreditCard, creditCard);
  }

  getCustomerEmail(email: string): Observable<Customer>{
    const params = new HttpParams()
    .set('email', email);
    return this.http.get<Customer>(Paths.main+Paths.getCustomerEmail, {params})
  }

  getMaxId(): Observable<number>{
    return this.http.get<number>(Paths.main+Paths.getMaxId)
  }

  addOrderDetail(orderDetail: OrderDetail): Observable<any>{
    return this.http.post<any>(Paths.main+Paths.addOrderDetail, orderDetail);
  }

  addOrder(order: Order):Observable<any>{
    return this.http.post<any>(Paths.main+Paths.addOrder, order);
  }

  getOrderDetailsByCustomerId(): Observable<OrderDetail[]>{
    const params = new HttpParams()
    .set('id', this.authenticatedCustomer?.id!);
    return this.http.get<OrderDetail[]>(Paths.main+Paths.getOrderDetailsByCustomerId, {params});
  }

  getOrdersByCustomerId(): Observable<Order[]>{
    const params = new HttpParams()
    .set('id', this.authenticatedCustomer?.id!);
    return this.http.get<Order[]>(Paths.main+Paths.getOrdersByCustomerId, {params});
  }

  getReturnMaxId(): Observable<number>{
    return this.http.get<number>(Paths.main+Paths.getReturnMaxId)
  }

  addReturnDetail(returnDetail: ReturnDetail): Observable<any>{
    return this.http.post<any>(Paths.main+Paths.addReturnDetail, returnDetail);
  }

  addReturn(returnToAdd: Return):Observable<any>{
    
    return this.http.post<any>(Paths.main+Paths.addReturn, returnToAdd);
  }

  getReturnDetailsByCustomerId(): Observable<ReturnDetail[]>{
    const params = new HttpParams()
    .set('id', this.authenticatedCustomer?.id!);
    return this.http.get<ReturnDetail[]>(Paths.main+Paths.getReturnDetailsByCustomerId, {params});
  }

  getReturnsByCustomerId(): Observable<Return[]>{
    const params = new HttpParams()
    .set('id', this.authenticatedCustomer?.id!);
    return this.http.get<Return[]>(Paths.main+Paths.getAllReturnsByCustomerId, {params});
  }

  getAllProductsByOrderId(nOrder: number): Observable<Order[]>{
    const params = new HttpParams()
    .set('id', nOrder);
    return this.http.get<Order[]>(Paths.main+Paths.getAllProductsByOrderId, {params});
  }

  getAllOrders(): Observable<Order[]>{
    return this.http.get<Order[]>(Paths.main+Paths.orders)
  }

  getAllOrderDetails(): Observable<OrderDetail[]>{
    return this.http.get<OrderDetail[]>(Paths.main+Paths.orderDetails)
  }

  getAllReturns(): Observable<Return[]>{
    return this.http.get<Return[]>(Paths.main+Paths.returns)
  }

  getAllReturnDetails(): Observable<ReturnDetail[]>{
    return this.http.get<ReturnDetail[]>(Paths.main+Paths.returnDetails)
  }

  preOrder(fromBasket: boolean){
    this.productsToOrder = [];
    if(fromBasket)
      this.productsToOrder = this.basketProducts;
    else
      this.productsToOrder.push(this.productDetails);
  }
}
