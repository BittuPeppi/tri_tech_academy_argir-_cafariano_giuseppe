import { Routes } from '@angular/router';
import { AddProductComponent } from './components/add-product/add-product.component';
import { HomeComponent } from './components/home/home.component';
import { ProductsComponent } from './components/products/products.component';
import { ProductDetailsComponent } from './components/product-details/product-details.component';
import { BasketComponent } from './components/basket/basket.component';
import { LoginComponent } from './components/login/login.component';
import { SignInComponent } from './components/sign-in/sign-in.component';
import { ProfileComponent } from './components/profile/profile.component';
import { PreOrderComponent } from './components/pre-order/pre-order.component';
import { OrderComponent } from './components/order/order.component';
import { ReturnComponent } from './components/return/return.component';
import { AdministrationComponent } from './components/administration/administration.component';


export const routes: Routes = [
    {path: '', component: HomeComponent},
    {path: 'products', component: ProductsComponent},
    {path: 'productDetails', component: ProductDetailsComponent},
    {path: 'basket', component: BasketComponent},
    {path: 'login', component: LoginComponent},
    {path: 'signIn', component: SignInComponent},
    {path: 'profile', component: ProfileComponent},
    {path: 'preOrder', component: PreOrderComponent},
    {path: 'orders', component: OrderComponent},
    {path: 'return', component: ReturnComponent},
    {path: 'administration', component: AdministrationComponent},
    {path: 'addProduct', component: AddProductComponent},
];
