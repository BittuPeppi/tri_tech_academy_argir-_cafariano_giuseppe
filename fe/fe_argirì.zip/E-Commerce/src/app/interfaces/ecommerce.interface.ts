import { Data } from "@angular/router"

export interface Category{
    id: number,
    name: string,
    image: any
}

export interface Seller{
    id: number,
    name: string,
    address: string,
    email: string
}

export interface Product{
    id: number,
    name: string,
    description: string,
    price: number,
    quantity: number,
    category: Category | null,
    seller: Seller | null,
    photo: any
}

export interface ProductInformation{
    product: Product,
    quantity: number,
    showOption: boolean,
    options: number[]
}

export interface Image{
    id: number,
    image: any
}

export interface Customer{
    id: number,
    firstName: string,
    lastName: string,
    email: string,
    phone: string,
    birthDate: Date,
    address: string,
    password: string
}

export interface CreditCard{
    id: number,
    card: string,
    cvv: string,
    deadline: Date,
    holder: string,
    customer: Customer
}

export interface OrderDetail{
    id: number,
    deliveryDate: Date | null,
    orderDate: Date,
    status: string,
    paymentMethod: string,
    shippingDate: Date | null
}

export interface Order{
    id: number,
    customer: Customer,
    product: Product,
    quantity: number,
    detail: OrderDetail
}

export interface ProductOrder{
    order: OrderDetail,
    products: ProductInformation[]
}

export interface ReturnDetail{
    id: number,
    returnDate: Date
}

export interface Return{
    id: number,
    detail: ReturnDetail,
    product: Product,
    customer: Customer
}

export interface ProductReturn{
    return: ReturnDetail,
    products: ProductInformation[]
}
