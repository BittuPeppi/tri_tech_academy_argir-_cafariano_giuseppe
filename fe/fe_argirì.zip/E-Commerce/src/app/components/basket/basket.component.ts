import { CommonModule } from '@angular/common';
import { Component, HostListener, OnInit } from '@angular/core';
import { HeaderComponent } from '../header/header.component';
import { ECommerceService } from '../../services/ecommerce.service';
import { Product, ProductInformation } from '../../interfaces/ecommerce.interface';
import { Router } from '@angular/router';

@Component({
  selector: 'app-basket',
  standalone: true,
  imports: [CommonModule, HeaderComponent],
  templateUrl: './basket.component.html',
  styleUrl: './basket.component.css'
})
export class BasketComponent{
  constructor(private service:ECommerceService, private router: Router){}
  
  options: number[] = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
  product!: ProductInformation;

  @HostListener('click', ['$event']) handleClickOutside(event: Event){
    if((event.target as HTMLElement).className != "select-options" &&  (event.target as HTMLElement).className != "select-header" && (event.target as HTMLElement).parentElement?.className != "select-header"){
      this.product.showOption = false;
    }
  }
  
  get getProducts(){
    return this.service.basketProducts;
  }

  viewOptions(product: ProductInformation) {
    this.product = product;
    if(this.product.product.quantity>=10)
      this.product.options = [1,2,3,4,5,6,7,8,9,10];
    else{
      for(let i=0; i<this.product.product.quantity; i++)
        this.product.options.push(i+1);
    }
    this.product.showOption = !this.product.showOption;
    
  }

  selectOption(option: number) {
    this.product.showOption = false;
    this.product.quantity = option;
  }

  getArticleNumber(){
    let articles = 0;
    let totPrice:number = 0;
    this.getProducts.forEach(product =>{
      articles += product.quantity;
      totPrice += (product.product.price*product.quantity)
    })
    return {articles, totPrice};
  }

  deleteProduct(product: ProductInformation){
    this.service.deleteProductFromBasket(product);
  }

  addProductsToOrder(){
    if(this.service.authenticatedCustomer == null){
      this.router.navigate(['/login']);
      this.service.setFromSignIn(false);
    }
    else{
      this.service.preOrder(true);
      this.router.navigate(['/preOrder']);
    }
  }

}
