import { Component, OnInit } from '@angular/core';
import { Image} from '../../enums/ecommerce.enum';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { ECommerceService } from '../../services/ecommerce.service';
import { CommonModule, Location } from '@angular/common';
import { Router, RouterLink } from '@angular/router';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [FormsModule, ReactiveFormsModule, CommonModule, RouterLink],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent implements OnInit{
  constructor(private service: ECommerceService, private fb: FormBuilder, private location: Location, private router: Router){}
  form!: FormGroup;
  viewPassword = false;
  src = Image.eyeClose;
  isAuthenticated: boolean = true;
  isOnFocus: boolean = true;

  ngOnInit(): void {
    this.form = this.fb.group({
      email: [null, [Validators.required, Validators.email]],
      password: [null, [Validators.required, Validators.pattern(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&.,:;-_)])[A-Za-z\d@$!%*?&.,:;-_]+$/), Validators.minLength(8)]]
    })
  }

  onSubmit(){
    this.service.authentication(this.form.value.email, this.form.value.password).subscribe(data=>{
      if(data != null){
        this.isAuthenticated = true;
        this.service.setAuthenticatedCustomer(data);
        if(this.service.fromSignIn)
          this.router.navigate(['/']);
        else
          (this.location as any).back();
      }
      else
      this.isOnFocus = false;
        this.isAuthenticated = false;
        this.form.reset();
        
    })
  }

  onFocus(){
    this.isOnFocus = true;
  }

  showPassword(){
    this.viewPassword = !this.viewPassword;
    if(this.src == Image.eyeClose)
      this.src = Image.eyeOpen;
    else
      this.src = Image.eyeClose;
  }
  

  get getImage(){
    return Image;
  }
}
