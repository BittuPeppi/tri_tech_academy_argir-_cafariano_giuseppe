import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { ECommerceService } from '../../services/ecommerce.service';
import { Category, Product, Seller} from '../../interfaces/ecommerce.interface';
import { AbstractControl, FormBuilder, FormControl, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { Observable, forkJoin, from, map, switchMap } from 'rxjs';

@Component({
  selector: 'app-add-product',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FormsModule],
  templateUrl: './add-product.component.html',
  styleUrl: './add-product.component.css'
})
export class AddProductComponent implements OnInit{
  constructor(private service: ECommerceService, private fb:FormBuilder){}
  sellers: Seller[] = [];
  categories: Category[] = [];
  form!: FormGroup;

  ngOnInit(): void {
    this.form = this.fb.group({
      productName: [null, [Validators.required, Validators.minLength(3)]],
      productDescription: [null, Validators.required],
      productPrice: [null, [Validators.required, Validators.min(0)]],
      productQuantity: [null, [Validators.required, Validators.min(0)]],
      productCategory: ['blank', [Validators.required, this.validateSelect]],
      productSeller: ['blank', [Validators.required, this.validateSelect]],
      productPhoto: ['', [Validators.required]],
    })

    this.service.getSellers().subscribe(data => {
      this.sellers = data;
    });

    this.service.getCategories().subscribe(data => {
      this.categories = data;
    });
  }

  imageUrl: string = "../../assets/upload.png";

  validateSelect(control:AbstractControl) {
    const selectedValue = control.value;
    if (selectedValue === 'blank') {
      return { invalidOption: true };
    }
    return null;
  }

  onDrop(event: DragEvent) {
    event.preventDefault();
    const file = event.dataTransfer?.files[0];
    this.uploadImage(file);
  }

  onDragOver(event: DragEvent) {
    event.preventDefault();
  }

  onFileSelected(event: Event) {
    const input = event.target as HTMLInputElement;
    const file = input.files?.[0];
    this.uploadImage(file);
  }

  uploadImage(file: File | undefined) {
    if (file && file.type.startsWith('image/')) {
      const image = URL.createObjectURL(file);
      this.imageUrl = image;
      this.form.patchValue({
        productPhoto: file
      });      
    }
  }

  getCategory(id:number): Category | null{
    this.service.getCategoryById(id).subscribe(data => {return data});
    return null;
  }

  getSeller(id:number): Category | null{
    this.service.getSellerById(id).subscribe(data => {return data});
    return null;
  }

  convertImageToBase64(file: File): Promise<string> {
    return new Promise<string>((resolve, reject) => {
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64String = reader.result as string;
        
        
        resolve(base64String.split(',')[1]);
      };
  
      reader.onerror = () => {
        reject(new Error('Errore durante la lettura del file.'));
      };
  
      reader.readAsDataURL(file);
    });
  }

  onSubmit() {
    let categoryData = this.service.getCategoryById(this.form.value.productCategory);
    let sellerData = this.service.getSellerById(this.form.value.productSeller);
    let photoData = from(this.convertImageToBase64(this.form.value.productPhoto));

    forkJoin({
      categoryData: categoryData,
      sellerData: sellerData,
      photoData: photoData
    }).subscribe(result => {
      const category = result.categoryData;
      const seller = result.sellerData;
      const base64Image = result.photoData;
    
      const product: Product = {
        id: 0,
        name: this.form.value.productName,
        description: this.form.value.productDescription,
        price: this.form.value.productPrice,
        quantity: this.form.value.productQuantity,
        category: category,
        seller: seller,
        photo: base64Image
      };
    
      this.service.addProduct(product).subscribe();
    });
    
  }
  
}
