import { Component, OnInit } from '@angular/core';
import { HeaderComponent } from '../header/header.component';
import { Product } from '../../interfaces/ecommerce.interface';
import { ECommerceService } from '../../services/ecommerce.service';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { LoadingComponent } from '../loading/loading.component';

@Component({
  selector: 'app-products',
  standalone: true,
  imports: [CommonModule, HeaderComponent, LoadingComponent],
  templateUrl: './products.component.html',
  styleUrl: './products.component.css'
})
export class ProductsComponent implements OnInit {
  constructor(private service: ECommerceService, private router:Router){}
  products: Product[] = [];

  ngOnInit(): void {
    this.service.loading = true;
    if(this.service.fromSearch){
      
      this.service.getAllProductsByName().subscribe(data =>{
        this.service.loading = false;
        this.products = data;
      })
    }else{
      this.service.getAllProductsByCategory().subscribe(data =>{
        this.service.loading = false;
        this.products = data;
      })
    }
    
  }

  get getLoading(){
    return this.service.loading;
  }

  splitPrice(price: number): string[]{
    let parts: string[] = price.toString().split('.');
    return parts;
    
  }

  viewProductDetails(product: Product){
    this.service.setProduct(product);
    this.router.navigate(['/productDetails']);
  }

}
