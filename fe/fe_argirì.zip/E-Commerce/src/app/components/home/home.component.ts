import { Component, OnInit } from '@angular/core';
import { ECommerceService } from '../../services/ecommerce.service';
import { Category, Product } from '../../interfaces/ecommerce.interface';
import { CommonModule } from '@angular/common';
import { HeaderComponent } from '../header/header.component';
import { Image } from '../../enums/ecommerce.enum';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { LoadingComponent } from '../loading/loading.component';


@Component({
  selector: 'app-home',
  standalone: true,
  imports: [CommonModule, HeaderComponent, ReactiveFormsModule, FormsModule, LoadingComponent],
  templateUrl: './home.component.html',
  styleUrl: './home.component.css'
})
export class HomeComponent implements OnInit{
  constructor(private service: ECommerceService, private fb: FormBuilder, private router: Router){}

  form!: FormGroup;
  categories: Category[] = [];
  isInputFocused= false;

  
  products: Product[] = [];

  ngOnInit(): void {
    this.service.loading = true;
    this.service.getAllProducts().subscribe(data =>{
      this.service.loading = false;
      this.products = data;
    })

    this.form = this.fb.group({
      name: [null],
    })

    this.service.getCategories().subscribe(data => {
      this.categories = data;
      
    })
  }

  get getLoading(){
    return this.service.loading;
  }

  viewProducts(category: Category){
    this.service.setCategory(category);
    this.service.setFromSearch(false);
    this.router.navigate(['/products']);
  }

  receiveData(value: boolean){
    this.isInputFocused = value;
  }

  

  get getImagePaths(){
    return Image;
  }



}
