import { Component, OnInit } from '@angular/core';
import { Image } from '../../enums/ecommerce.enum';
import { AbstractControl, AsyncValidatorFn, FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, ValidationErrors, Validators } from '@angular/forms';
import { ECommerceService } from '../../services/ecommerce.service';
import { CommonModule } from '@angular/common';
import { Customer } from '../../interfaces/ecommerce.interface';
import { Observable, map } from 'rxjs';
import { Router } from '@angular/router';

@Component({
  selector: 'app-sign-in',
  standalone: true,
  imports: [ReactiveFormsModule, FormsModule, CommonModule],
  templateUrl: './sign-in.component.html',
  styleUrl: './sign-in.component.css'
})
export class SignInComponent implements OnInit{
  constructor(private service:ECommerceService, private fb:FormBuilder, private router: Router){}
  form!: FormGroup;

  ngOnInit(): void {
    
    
    this.form = this.fb.group({
      firstName: [null, [Validators.required, Validators.minLength(3), Validators.pattern(/^[a-zA-Z]+$/)]],
      lastName: [null, [Validators.required, Validators.minLength(3), Validators.pattern(/^[a-zA-Z]+$/)]],
      email: [null, [Validators.required, Validators.email], [this.validateEmail()]],
      phone: [null, [Validators.required, Validators.minLength(10), Validators.maxLength(10), Validators.pattern(/^[0-9]+$/)]],
      birthDate: [null, [Validators.required, this.validateBirthDate]],
      address: [null, [Validators.required]],
      password: [null, [Validators.required, Validators.pattern(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&.,:;-_)])[A-Za-z\d@$!%*?&.,:;-_]+$/), Validators.minLength(8)]],
      confirmPassword: ['', [Validators.required]],
    }, {
      validators: this.validateConfirmPassword
    });
  }

  get getImage(){
    return Image;
  }

  onSubmit(){
    const customer: Customer = {
      id: 0,
      firstName: this.form.value.firstName,
      lastName: this.form.value.lastName,
      email: this.form.value.email,
      phone: this.form.value.phone,
      birthDate: this.form.value.birthDate,
      address: this.form.value.address,
      password: this.form.value.password
    }
    this.service.addCustomer(customer).subscribe(()=>{
      this.form.reset();
      this.router.navigate(['/login'])
      this.service.setFromSignIn(true);
    });

  }

  validateBirthDate(control:AbstractControl) {
    const birthDate = new Date(control.value);
    const today = new Date();
    
    if (today.getFullYear() - birthDate.getFullYear() < 18 || (today.getFullYear() - birthDate.getFullYear() == 18 && birthDate.getMonth() > today.getMonth() ) || (today.getFullYear() - birthDate.getFullYear() == 18 && today.getMonth() == birthDate.getMonth() && birthDate.getDate() > today.getDate())) {
      return { invalidOption: true };
    }
    return null;
  }

  validateEmail(): AsyncValidatorFn {
    return (control: AbstractControl): Observable<ValidationErrors | null> => {
      return this.service.getCustomerEmail(control.value).pipe(
        map(data => {
          if (data) {
            return { invalidEmail: true };
          } else {
            return null;
          }
        })
      );
    };
  }

  validatePassword(regex: RegExp): ValidationErrors | null{
    return (control: AbstractControl)=>{
      if(!regex.test(control.value)){
        return { invalidOption: true };
      }
      return null;
    }
  }

  validateConfirmPassword(control: AbstractControl): ValidationErrors | null {
    const confirmPassword = control.get('confirmPassword')?.value;
    const passwordControl = control.get('password')?.value;
  
    if (confirmPassword !== passwordControl) {
      control.get('confirmPassword')?.setErrors({ passwordMismatch: true });
      return { passwordMismatch: true };
    }
  
    return null;
  }

  
}
