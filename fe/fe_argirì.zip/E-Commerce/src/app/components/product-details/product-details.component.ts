import { Component, ElementRef, HostListener, OnInit } from '@angular/core';
import { HeaderComponent } from '../header/header.component';
import { ECommerceService } from '../../services/ecommerce.service';
import { Product } from '../../interfaces/ecommerce.interface';
import { Router, RouterLink, RouterLinkActive } from '@angular/router';
import { CommonModule, NgIf } from '@angular/common';

@Component({
  selector: 'app-product-details',
  standalone: true,
  imports: [HeaderComponent, RouterLink, RouterLinkActive, CommonModule, NgIf],
  templateUrl: './product-details.component.html',
  styleUrl: './product-details.component.css'
})
export class ProductDetailsComponent implements OnInit{
  constructor(private service:ECommerceService, private router: Router){}
  product!: Product;
  options: number[] = [];
  showOptions: boolean = false;
  selectedOption: number = 1;
  @HostListener('click', ['$event']) handleClickOutside(event: Event){
    if((event.target as HTMLElement).className != "select-options" &&  (event.target as HTMLElement).className != "select-header" && (event.target as HTMLElement).parentElement?.className != "select-header"){
      this.showOptions = false;
    }
  }

  ngOnInit(): void {
    this.product = this.service.getProduct();
    if(this.product.quantity>=10)
      this.options = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
    else{
      for(let i=0;i<this.product.quantity; i++)
        this.options.push(i+1);
    }
  }

  splitPrice(price: number): string[]{
    let parts: string[] = price.toString().split('.');
    return parts; 
  }

  viewOptions() {
    this.showOptions = !this.showOptions;
    
  }

  selectOption(option: number) {
    this.selectedOption = option;
    this.showOptions = false;
  }

  addProductToBasket(){
    this.service.addProductToBasket(this.product, this.selectedOption);
  }

  addProductToOrder(){
    if(this.service.authenticatedCustomer == null){
      this.router.navigate(['/login']);
      this.service.setFromSignIn(false);
    }
    else{
      this.service.setProductDetails(this.product, this.selectedOption);
      this.service.preOrder(false);
      this.router.navigate(['/preOrder']);
    }
  }
  
}
