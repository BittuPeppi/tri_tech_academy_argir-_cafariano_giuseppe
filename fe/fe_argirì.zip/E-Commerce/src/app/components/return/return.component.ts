import { Component, OnInit } from '@angular/core';
import { ECommerceService } from '../../services/ecommerce.service';
import { AbstractControl, AsyncValidatorFn, FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, ValidationErrors, Validators } from '@angular/forms';
import { ProductInformation, Return, ReturnDetail } from '../../interfaces/ecommerce.interface';
import { CommonModule } from '@angular/common';
import { HeaderComponent } from '../header/header.component';
import { Observable, map } from 'rxjs';

@Component({
  selector: 'app-return',
  standalone: true,
  imports: [FormsModule, ReactiveFormsModule, CommonModule, HeaderComponent],
  templateUrl: './return.component.html',
  styleUrl: './return.component.css'
})
export class ReturnComponent implements OnInit{
  constructor(private service: ECommerceService, private fb: FormBuilder){}
  form!: FormGroup;
  products: ProductInformation[] = [];
  isDisabled = true;

  ngOnInit(): void {
    this.form = this.fb.group({
      nOrdine: [null, [Validators.required], [this.validateNOrder()]],
    });
  }

  isAdministrator(){
    return this.service.isAdministrator
  }

  onSubmit(){
    this.service.getAllProductsByOrderId(this.form.value.nOrdine).subscribe(data =>{
      data.forEach(order =>{
        this.products.push({product: order.product, quantity: order.quantity, showOption: false, options:[]})
      })
    })
  }

  onChange(product: ProductInformation){
    product.showOption = !product.showOption;
    this.isDisabled = true;
    this.products.forEach(product=>{
      if(product.showOption == true)
        this.isDisabled = false;
    })
  }

  validateNOrder(): AsyncValidatorFn {
    return (control: AbstractControl): Observable<ValidationErrors | null> => {
      return this.service.getAllProductsByOrderId(control.value).pipe(
        map(data => {
          if (data.length == 0) {
            return { invalidNOrder: true };
          } else {
            return null;
          }
        })
      );
    };
  }

  doReturn(){
    this.service.getReturnMaxId().subscribe(data => {
      let nextId: number = 0;
      if (data == null)
        nextId = 0;
      else
        nextId = data + 1;
    
      const returnDetail: ReturnDetail = {
        id: nextId,
        returnDate: new Date(new Date().toLocaleDateString('en-US', { year: 'numeric', month: '2-digit', day: '2-digit' })),
      };

      this.service.addReturnDetail(returnDetail).subscribe(()=>{
        this.products.forEach(product =>{
          if(product.showOption){
            const returnToAdd: Return = {
              id: 1,
              customer: this.service.authenticatedCustomer!,
              product: product.product,
              detail: returnDetail
            }
            this.service.addReturn(returnToAdd).subscribe();
          }
        })
        
      })
    });
  }
  


}
