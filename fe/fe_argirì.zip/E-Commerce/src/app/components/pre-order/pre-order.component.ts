import { Component, OnInit } from '@angular/core';
import { Image } from '../../enums/ecommerce.enum';
import { CommonModule } from '@angular/common';
import { ECommerceService } from '../../services/ecommerce.service';
import { CreditCard, Order, OrderDetail, ProductInformation } from '../../interfaces/ecommerce.interface';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { concatMap } from 'rxjs';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-pre-order',
  standalone: true,
  imports: [CommonModule, FormsModule, ReactiveFormsModule, RouterLink],
  templateUrl: './pre-order.component.html',
  styleUrl: './pre-order.component.css'
})
export class PreOrderComponent implements OnInit{
  constructor(private service: ECommerceService, private fb: FormBuilder){}
  isDisabled = true;
  isButtonDisabled = true;
  creditCardIsPresent = false;
  creditCard!: CreditCard;
  formCreditCard!: FormGroup;
  products!: ProductInformation[];

  ngOnInit(): void {
    this.service.getCreditCardByCustomer().subscribe(data=>{
      this.creditCard = data;
      if(this.creditCard == null)
        this.creditCardIsPresent = false;
      else
        this.creditCardIsPresent = true;
    });

    this.formCreditCard = this.fb.group({
      name: [{value: '', disabled:true}, [Validators.required, Validators.minLength(3)]],
      nCard: [{value: '', disabled:true}, [Validators.required, Validators.minLength(16), Validators.maxLength(16)]],
      cvv: [{value: '', disabled:true}, [Validators.required, Validators.minLength(3), Validators.maxLength(3)]],
      deadline: [{value: '', disabled:true}, [Validators.required, Validators.minLength(3)]],
    });

    this.products = this.service.productsToOrder;
  }

  get getImage(){
    return Image;
  }

  onChange(value: string){
    this.isButtonDisabled = false;
    if(value == 'newCard'){
      this.formCreditCard.enable()
      this.isDisabled = false;
      this.service.setPaymentMethod('carta di credito');
    }
    else if(value == 'registeredCard'){
      this.formCreditCard.disable();
      this.isDisabled = true;
      this.formCreditCard.patchValue({
        name: this.creditCard.holder,
        nCard: this.creditCard.card,
        cvv: this.creditCard.cvv,
        deadline: this.creditCard.deadline,
      });
      this.service.setPaymentMethod('paga alla consegna');
    }
    else{
      this.formCreditCard.disable();
      this.isDisabled = true;
      this.formCreditCard.reset();
      this.service.setPaymentMethod('carta di credito');
    }
  }

  onSubmit(){
    const creditCard: CreditCard = {
      id: 0,
      deadline: this.formCreditCard.value.deadline,
      card: this.formCreditCard.value.nCard,
      cvv: this.formCreditCard.value.cvv,
      customer: null!,
      holder: this.formCreditCard.value.name,
    }

    this.service.addCreditCard(creditCard).subscribe();
  }

  calcTotalPrice(){
    let totalPrice = 0;
    this.products.forEach(product =>{
      totalPrice += (product.quantity * product.product.price);
    })
    return totalPrice;
  }

  doOrder(){
    this.isButtonDisabled = true;
    this.service.getMaxId().subscribe(data => {
      let nextId: number = 0;
      if (data == null)
        nextId = 0;
      else
        nextId = data + 1;
    
      const orderDetail: OrderDetail = {
        id: nextId,
        deliveryDate: null,
        status: 'In elaborazione',
        paymentMethod: this.service.paymentMethod,
        orderDate: new Date(new Date().toLocaleDateString('en-US', { year: 'numeric', month: '2-digit', day: '2-digit' })),
        shippingDate: null
      };

      this.service.addOrderDetail(orderDetail).subscribe(()=>{
        this.service.productsToOrder.forEach(product =>{
          const order: Order = {
            id: 1,
            customer: this.service.authenticatedCustomer!,
            product: product.product,
            quantity: product.quantity,
            detail: orderDetail
          }
          this.service.addOrder(order).subscribe();
        })
        
      })
    });
  }
}
