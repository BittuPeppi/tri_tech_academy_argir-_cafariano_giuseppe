import { Component, OnInit } from '@angular/core';
import { ECommerceService } from '../../services/ecommerce.service';
import { CommonModule } from '@angular/common';
import { Order, ProductInformation, ProductOrder, ProductReturn } from '../../interfaces/ecommerce.interface';
import { RouterLink } from '@angular/router';
import { HeaderComponent } from '../header/header.component';

@Component({
  selector: 'app-order',
  standalone: true,
  imports: [CommonModule, RouterLink, HeaderComponent],
  templateUrl: './order.component.html',
  styleUrl: './order.component.css'
})
export class OrderComponent implements OnInit {
  constructor(private service: ECommerceService){}
  orders!: ProductOrder[];
  returns!: ProductReturn[];
  viewOrders = true;

  ngOnInit(): void {
    this.orders = [];
    this.returns = [];
    if(this.service.authenticatedCustomer?.email=="admin@admin"){
      this.service.getAllOrderDetails().subscribe(data =>{
        data.forEach(orderDetail =>{
          this.orders.push({order: orderDetail, products: []});
        });

        this.service.getAllOrders().subscribe(data =>{
          this.orders.forEach(order=>{
            data.forEach(o =>{            
              if(o.detail.id == order.order.id){
                  order.products.push({product: o.product, quantity: o.quantity, showOption: false, options: []})
              }
            });
          });
          
        });
      });

      this.service.getAllReturnDetails().subscribe(data =>{
        data.forEach(returnDetail =>{
          this.returns.push({return: returnDetail, products: []});
        })
        
        this.service.getAllReturns().subscribe(data =>{
          this.returns.forEach(returnToCheck=>{
            data.forEach(r =>{            
              if(r.detail.id == returnToCheck.return.id){
                  returnToCheck.products.push({product: r.product, quantity: 1, showOption: false, options: []})
              }
            })
          })
          
        })
      })
    }else{
        this.service.getOrderDetailsByCustomerId().subscribe(data =>{
          data.forEach(orderDetail =>{
            this.orders.push({order: orderDetail, products: []});
          })
          
          this.service.getOrdersByCustomerId().subscribe(data =>{
            this.orders.forEach(order=>{
              data.forEach(o =>{            
                if(o.detail.id == order.order.id){
                    order.products.push({product: o.product, quantity: o.quantity, showOption: false, options: []})
                }
              })
            })
            
          })
        });

        
        this.service.getReturnDetailsByCustomerId().subscribe(data =>{
          data.forEach(returnDetail =>{
            this.returns.push({return: returnDetail, products: []});
          })
          
          this.service.getReturnsByCustomerId().subscribe(data =>{
            this.returns.forEach(returnToCheck=>{
              data.forEach(r =>{            
                if(r.detail.id == returnToCheck.return.id){
                    returnToCheck.products.push({product: r.product, quantity: 1, showOption: false, options: []})
                }
              })
            })
            console.log("Resi "+this.returns);
            
          })
        })
    }
  }

  totalEur(products: ProductInformation[]){
    let total = 0;
    products.forEach(product =>{
      total += (product.quantity * product.product.price);
    })
    return total;
  }

  isAdministrator(){
    return this.service.isAdministrator;
  }

  onChange(event: any){
    if(event.target.value == "orders")
      this.viewOrders = true;
    else
      this.viewOrders = false;
  }


}
