import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { Image } from '../../enums/ecommerce.enum';
import { CommonModule } from '@angular/common';
import { Router, RouterLink } from '@angular/router';
import { ECommerceService } from '../../services/ecommerce.service';
import { FormGroup, FormsModule, ReactiveFormsModule } from '@angular/forms';

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [CommonModule, RouterLink, ReactiveFormsModule, FormsModule],
  templateUrl: './header.component.html',
  styleUrl: './header.component.css'
})
export class HeaderComponent implements OnInit{
constructor(private service:ECommerceService, private router: Router){}

  @Output() sendData = new EventEmitter<boolean>();
  isFocused!: boolean;
  customer!: string;
  nameToSearch = "";

  ngOnInit(): void {
    if(this.service.authenticatedCustomer == null)
      this.customer = "accedi";
    else
      this.customer = this.service.authenticatedCustomer.firstName;
  }

  isAdministrator(){
    return this.service.isAdministrator;
  }

  search(){
    this.service.nameToSearch = this.nameToSearch;
    this.service.setFromSearch(true);
    this.router.navigate(['/products']);
  }

  onFocus(){
    this.isFocused = true;
    this.sendData.emit(this.isFocused);
  }

  onBlur(){
    this.isFocused = false;
    this.sendData.emit(this.isFocused);
  }

  goToProfile(){
    if(this.customer == "accedi"){
      this.router.navigate(['/login'])
      this.service.setFromSignIn(false);
    }
    else{
      this.router.navigate(['/profile']);
    }
  }

  goToOrders(){
    if(this.customer == "accedi"){
      this.router.navigate(['/login'])
      this.service.setFromSignIn(false);
    }
    else{
      this.router.navigate(['/orders']);
    }
  }

  get getImagePaths(){
    return Image;
  }

}
