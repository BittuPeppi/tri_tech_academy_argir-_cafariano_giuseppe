package com.tricommerce.demo.services.impl;

import com.tricommerce.demo.models.ReturnDetail;
import com.tricommerce.demo.repositories.ReturnDetailRepository;
import com.tricommerce.demo.services.ReturnDetailService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ReturnDetailServiceImpl implements ReturnDetailService {
    @Autowired
    private ReturnDetailRepository returnDetailRepository;
    @Override
    public void addReturnDetails(ReturnDetail returnDetail) {
        this.returnDetailRepository.save(returnDetail);
    }

    @Override
    public List<ReturnDetail> getAllReturnDetails() {
        return this.returnDetailRepository.findAll();
    }

    @Override
    public List<ReturnDetail> getReturnDetailsByCustomerId(Long id) {
        return this.returnDetailRepository.getReturnDetailByCustomerId(id);
    }

    @Override
    public Long getReturnMaxId() {
        return this.returnDetailRepository.getReturnMaxId();
    }
}
