package com.tricommerce.demo.models;

import javax.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "ag_order")
public class Order {
    @Id
    @GeneratedValue
    private Long id;
    @ManyToOne
    @JoinColumn(name = "customer", referencedColumnName = "id")
    private Customer customer;

    @ManyToOne
    @JoinColumn(name = "product", referencedColumnName = "id")
    private Product product;

    private Long quantity;

    @ManyToOne
    @JoinColumn(name = "detail", referencedColumnName = "id")
    private OrderDetail detail;

    public Order(Customer customer, Product product, Long quantity, OrderDetail detail) {
        this.customer = customer;
        this.product = product;
        this.quantity = quantity;
        this.detail = detail;
    }
}
