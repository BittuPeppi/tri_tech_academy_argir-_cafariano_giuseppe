package com.tricommerce.demo.services;


import com.tricommerce.demo.models.Seller;

import java.util.List;

public interface SellerService {
    List<Seller> getAllSellers();
    Seller getSeller(Long id);
}
