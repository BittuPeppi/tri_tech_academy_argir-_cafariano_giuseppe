package com.tricommerce.demo.controllers;

import com.tricommerce.demo.models.Category;
import com.tricommerce.demo.models.Product;
import com.tricommerce.demo.services.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:4200/")
public class ProductController {
    @Autowired
    private ProductService productService;

    @GetMapping(value = "/products")
    public List<Product> getAllProducts(){
        return this.productService.getAllProducts();
    }

    @GetMapping(value = "/products/getByCategory")
    public List<Product> getAllProductsByCategory(@RequestParam Long id){
        return this.productService.getAllProductsByCategory(id);
    }

    @GetMapping(value = "/products/getByName")
    public List<Product> getAllProductsByName(@RequestParam String name){
        return this.productService.getAllProductsByName(name.toLowerCase());
    }

    @PostMapping(value = "/products/addProduct")
    public void addProduct(@RequestBody Product product){
        this.productService.addProduct(product);
    }
}
