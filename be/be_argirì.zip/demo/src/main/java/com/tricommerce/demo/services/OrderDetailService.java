package com.tricommerce.demo.services;

import com.tricommerce.demo.models.OrderDetail;

import java.util.List;

public interface OrderDetailService {
    void addOrderDetails(OrderDetail orderDetail);
    List<OrderDetail> getAllOrderDetails();
    List<OrderDetail> getOrderDetailsByCustomerId(Long id);
    Long getMaxId();
}
