package com.tricommerce.demo.controllers;

import com.tricommerce.demo.models.ReturnDetail;
import com.tricommerce.demo.services.ReturnDetailService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:4200/")
public class ReturnDetailController {
    @Autowired
    private ReturnDetailService returnDetailService;

    @GetMapping(value = "/returnDetails")
    public List<ReturnDetail> getAllOrderDetails(){
        return this.returnDetailService.getAllReturnDetails();
    }

    @GetMapping(value = "/getReturnMaxId")
    public Long getReturnMaxId(){
        return this.returnDetailService.getReturnMaxId();
    }

    @GetMapping(value = "/returnDetailsByCustomer")
    public List<ReturnDetail> getReturnDetailsByCustomerId(Long id){
        return this.returnDetailService.getReturnDetailsByCustomerId(id);
    }

    @PostMapping(value = "/addReturnDetails")
    public void addOrderDetails(@RequestBody ReturnDetail returnDetail){
        this.returnDetailService.addReturnDetails(returnDetail);
    }
}
