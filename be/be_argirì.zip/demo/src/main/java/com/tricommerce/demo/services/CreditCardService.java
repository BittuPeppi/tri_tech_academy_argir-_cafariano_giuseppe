package com.tricommerce.demo.services;

import com.tricommerce.demo.models.CreditCard;
import com.tricommerce.demo.models.Customer;

public interface CreditCardService {
    CreditCard getCreditCard(Long id);
    void addCreditCard(CreditCard creditCard);
    void updateCreditCard(CreditCard creditCard);
}
