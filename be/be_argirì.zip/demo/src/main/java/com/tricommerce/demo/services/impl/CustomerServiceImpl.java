package com.tricommerce.demo.services.impl;

import com.tricommerce.demo.models.Customer;
import com.tricommerce.demo.repositories.CustomerRepository;
import com.tricommerce.demo.services.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CustomerServiceImpl implements CustomerService {
    @Autowired
    private CustomerRepository customerRepository;
    @Override
    public List<Customer> getAllCustomers() {
        return this.customerRepository.findAll();
    }

    @Override
    public Customer getCustomer(Long id) {
        return this.customerRepository.findById(id).orElse(null);
    }

    @Override
    public Customer getCustomer(String email, String password) {
        return this.customerRepository.findByEmailAndPassword(email, password).orElse(null);
    }

    @Override
    public Customer getCustomerEmail(String email) {
        return this.customerRepository.findByEmail(email).orElse(null);
    }

    @Override
    public void deleteCustomer(Long id) {
        this.customerRepository.deleteById(id);
    }

    @Override
    public void updateCustomer(Customer customer) {
        this.customerRepository.save(customer);
    }

    @Override
    public void addCustomer(Customer customer) {
        this.customerRepository.save(customer);
    }
}
