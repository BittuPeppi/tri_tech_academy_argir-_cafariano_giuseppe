package com.tricommerce.demo.services.impl;

import com.tricommerce.demo.models.Order;
import com.tricommerce.demo.models.Return;
import com.tricommerce.demo.repositories.OrderRepository;
import com.tricommerce.demo.services.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class OrderServiceImpl implements OrderService {
    @Autowired
    private OrderRepository orderRepository;
    @Override
    public void addOrderDetails(Order order) {
        this.orderRepository.save(order);
    }

    @Override
    public List<Order> getAllOrders() {
        return this.orderRepository.findAll();
    }

    @Override
    public List<Order> getOrdersByCustomerId(Long id) {
        return this.orderRepository.findByCustomerId(id);
    }

    @Override
    public List<Order> getAllProductsByOrderId(Long id) {
        return this.orderRepository.findByDetailId(id);
    }
}
