package com.tricommerce.demo.controllers;

import com.tricommerce.demo.models.Customer;
import com.tricommerce.demo.services.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:4200/")
public class CustomerController {
    @Autowired
    private CustomerService customerService;

    @GetMapping(value = "/customers")
    public List<Customer> getAllCustomers(){
        return this.customerService.getAllCustomers();
    }

    @GetMapping(value = "/customers/getCustomer")
    public Customer getCustomer(@RequestParam String email, @RequestParam String password){
        return this.customerService.getCustomer(email, password);
    }

    @GetMapping(value = "/getCustomerEmail")
    public Customer getCustomerEmail(@RequestParam String email){
        return this.customerService.getCustomerEmail(email);
    }

    @PostMapping(value = "/customers/addCustomer")
    public void addCustomer(@RequestBody Customer customer){
        this.customerService.addCustomer(customer);
    }

    @PostMapping(value = "/customers/updateCustomer")
    public void updateCustomer(@RequestBody Customer customer){
        this.customerService.updateCustomer(customer);
    }
}
