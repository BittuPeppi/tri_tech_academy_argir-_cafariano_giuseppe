package com.tricommerce.demo.models;

import javax.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "AG_SELLER")
public class Seller {
    @Id
    @GeneratedValue
    private Long id;
    private String name;
    private String address;
    private String email;

    public Seller(String name, String address, String email) {
        this.name = name;
        this.address = address;
        this.email = email;
    }

    public Seller(Long id, String name) {
        this.id = id;
        this.name = name;
    }
}
