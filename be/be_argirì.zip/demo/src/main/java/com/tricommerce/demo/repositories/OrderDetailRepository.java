package com.tricommerce.demo.repositories;

import com.tricommerce.demo.models.OrderDetail;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
@Repository
public interface OrderDetailRepository extends JpaRepository<OrderDetail, Long> {
    //List<OrderDetail> findByCustomerId(Long id);
    @Query("SELECT MAX(o.id) FROM OrderDetail o")
    Long getMaxId();

    @Query("SELECT DISTINCT od FROM OrderDetail od, Order o WHERE od.id = o.detail AND o.customer.id = :id ORDER BY od.id DESC")
    List<OrderDetail> getOrderDetailByCustomerId(@Param("id") Long id);
}
