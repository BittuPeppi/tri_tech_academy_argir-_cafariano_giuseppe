package com.tricommerce.demo.repositories;

import com.tricommerce.demo.models.CreditCard;
import com.tricommerce.demo.models.Customer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;
@Repository
public interface CreditCardRepository extends JpaRepository<CreditCard, Long> {
    Optional<CreditCard> findByCustomerId(Long id);
}
