package com.tricommerce.demo.services.impl;

import com.tricommerce.demo.models.CreditCard;
import com.tricommerce.demo.models.Customer;
import com.tricommerce.demo.repositories.CreditCardRepository;
import com.tricommerce.demo.services.CreditCardService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CreditCardServiceImpl implements CreditCardService {
    @Autowired
    private CreditCardRepository creditCardRepository;
    @Override
    public CreditCard getCreditCard(Long id) {
        return this.creditCardRepository.findByCustomerId(id).orElse(null);
    }

    @Override
    public void addCreditCard(CreditCard creditCard) {
        this.creditCardRepository.save(creditCard);
    }

    @Override
    public void updateCreditCard(CreditCard creditCard) {
        this.creditCardRepository.save(creditCard);
    }
}
