package com.tricommerce.demo.services;

import com.tricommerce.demo.models.Return;

import java.util.List;

public interface ReturnService {
    void addReturn(Return returnToAdd);
    List<Return> getAllReturns();
    List<Return> getAllReturnsByCustomerId(Long id);

}
