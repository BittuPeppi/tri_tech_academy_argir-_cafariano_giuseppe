package com.tricommerce.demo.repositories;

import com.tricommerce.demo.models.Return;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ReturnRepository extends JpaRepository<Return, Long> {
    List<Return> findByCustomerId(Long id);
}
