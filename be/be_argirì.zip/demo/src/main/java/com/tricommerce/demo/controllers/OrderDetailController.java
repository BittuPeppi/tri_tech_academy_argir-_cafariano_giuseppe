package com.tricommerce.demo.controllers;

import com.tricommerce.demo.models.OrderDetail;
import com.tricommerce.demo.services.OrderDetailService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:4200/")
public class OrderDetailController {
    @Autowired
    private OrderDetailService orderDetailService;

    @GetMapping(value = "/orderDetails")
    public List<OrderDetail> getAllOrderDetails(){
        return this.orderDetailService.getAllOrderDetails();
    }

    @GetMapping(value = "/getMaxId")
    public Long getMaxId(){
        return this.orderDetailService.getMaxId();
    }

    @GetMapping(value = "/orderDetailsByCustomer")
    public List<OrderDetail> getOrderDetailsByCustomerId(Long id){
        return this.orderDetailService.getOrderDetailsByCustomerId(id);
    }

    @PostMapping(value = "/addOrderDetails")
    public void addOrderDetails(@RequestBody OrderDetail orderDetail){
        this.orderDetailService.addOrderDetails(orderDetail);
    }
}
