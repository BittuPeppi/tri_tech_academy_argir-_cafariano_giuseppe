package com.tricommerce.demo.services;

import com.tricommerce.demo.models.ReturnDetail;

import java.util.List;

public interface ReturnDetailService {
    void addReturnDetails(ReturnDetail returnDetail);
    List<ReturnDetail> getAllReturnDetails();
    List<ReturnDetail> getReturnDetailsByCustomerId(Long id);
    Long getReturnMaxId();
}
