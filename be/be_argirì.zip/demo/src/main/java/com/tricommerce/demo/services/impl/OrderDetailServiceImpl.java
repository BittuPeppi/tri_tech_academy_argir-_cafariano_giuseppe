package com.tricommerce.demo.services.impl;

import com.tricommerce.demo.models.OrderDetail;
import com.tricommerce.demo.repositories.OrderDetailRepository;
import com.tricommerce.demo.services.OrderDetailService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class OrderDetailServiceImpl implements OrderDetailService {
    @Autowired
    private OrderDetailRepository orderDetailRepository;
    @Override
    public void addOrderDetails(OrderDetail orderDetail) {
        this.orderDetailRepository.save(orderDetail);
    }

    @Override
    public List<OrderDetail> getAllOrderDetails() {
        return this.orderDetailRepository.findAll();
    }

    @Override
    public Long getMaxId() {
        return this.orderDetailRepository.getMaxId();
    }

    @Override
    public List<OrderDetail> getOrderDetailsByCustomerId(Long id) {
        return this.orderDetailRepository.getOrderDetailByCustomerId(id);
    }
}
