package com.tricommerce.demo.models;

import javax.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "AG_PRODUCT")
public class Product {
    @Id
    @GeneratedValue
    private Long id;
    private String name;
    private String description;
    private Double price;
    private Long quantity;
    @Lob
    private byte[] photo;
    @ManyToOne
    @JoinColumn(name = "seller", referencedColumnName = "id")
    private Seller seller;

    @ManyToOne
    @JoinColumn(name = "category", referencedColumnName = "id")
    private Category category;

    public Product(String name, String description, Double price, Long quantity, byte[] photo, Seller seller) {
        this.name = name;
        this.description = description;
        this.price = price;
        this.quantity = quantity;
        this.photo = photo;
        this.seller = seller;
    }
}
