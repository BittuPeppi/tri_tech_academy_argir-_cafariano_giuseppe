package com.tricommerce.demo.controllers;

import com.tricommerce.demo.models.Order;
import com.tricommerce.demo.models.Return;
import com.tricommerce.demo.services.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:4200/")
public class OrderController {
    @Autowired
    private OrderService orderService;

    @GetMapping(value = "/orders")
    public List<Order> getAllOrderDetails(){
        return this.orderService.getAllOrders();
    }

    @GetMapping(value = "/ordersByCustomer")
    public List<Order> getOrdersByCustomerId(Long id){
        return this.orderService.getOrdersByCustomerId(id);
    }

    @GetMapping(value = "/getProductByOrderId")
    public List<Order> getAllProductsByReturnId(@RequestParam Long id){
        return this.orderService.getAllProductsByOrderId(id);
    }

    @PostMapping(value = "/addOrder")
    public void addOrderDetails(@RequestBody Order order){
        this.orderService.addOrderDetails(order);
    }
}
