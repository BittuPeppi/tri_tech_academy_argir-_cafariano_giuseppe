package com.tricommerce.demo.services.impl;

import com.tricommerce.demo.models.Return;
import com.tricommerce.demo.repositories.ReturnRepository;
import com.tricommerce.demo.services.ReturnService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ReturnServiceImpl implements ReturnService {
    @Autowired
    private ReturnRepository returnRepository;

    @Override
    public void addReturn(Return returnToAdd) {
        this.returnRepository.save(returnToAdd);
    }

    @Override
    public List<Return> getAllReturns() {
        return this.returnRepository.findAll();
    }

    @Override
    public List<Return> getAllReturnsByCustomerId(Long id) {
        return this.returnRepository.findByCustomerId(id);
    }


}
