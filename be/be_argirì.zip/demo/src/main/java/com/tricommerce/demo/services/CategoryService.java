package com.tricommerce.demo.services;

import com.tricommerce.demo.models.Category;
import com.tricommerce.demo.models.Product;

import java.util.List;

public interface CategoryService {
    List<Category> getAllCategories();
    Category getCategory(Long id);
    void addCategory(Category category);
}
