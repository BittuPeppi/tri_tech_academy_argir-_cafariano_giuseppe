package com.tricommerce.demo.services.impl;

import com.tricommerce.demo.models.Category;
import com.tricommerce.demo.models.Product;
import com.tricommerce.demo.repositories.ProductRepository;
import com.tricommerce.demo.services.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProductServiceImpl implements ProductService {
    @Autowired
    private ProductRepository productRepository;
    @Override
    public List<Product> getAllProducts() {
        return this.productRepository.findAll();
    }

    @Override
    public void addProduct(Product product) {
        this.productRepository.save(product);
    }

    @Override
    public List<Product> getAllProductsByCategory(Long id) {
        return this.productRepository.findByCategoryId(id);
    }

    @Override
    public List<Product> getAllProductsByName(String name) {
        return this.productRepository.findByNameLikeIgnoreCase(name);
    }
}
