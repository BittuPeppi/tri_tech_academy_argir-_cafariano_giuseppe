package com.tricommerce.demo.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "AG_CATEGORY")
public class Category {
    @Id
    @GeneratedValue
    private Long id;
    private String name;
    @Lob
    private byte[] image;

    public Category(String name, byte[] image) {
        this.name = name;
        this.image = image;
    }
}
