package com.tricommerce.demo.services;

import com.tricommerce.demo.models.Order;
import com.tricommerce.demo.models.Return;

import java.util.List;

public interface OrderService {
    void addOrderDetails(Order order);
    List<Order> getAllOrders();
    List<Order> getOrdersByCustomerId(Long id);
    List<Order> getAllProductsByOrderId(Long id);
}
