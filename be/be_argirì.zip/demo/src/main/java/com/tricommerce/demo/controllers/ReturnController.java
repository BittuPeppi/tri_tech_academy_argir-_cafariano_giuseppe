package com.tricommerce.demo.controllers;

import com.tricommerce.demo.models.Return;
import com.tricommerce.demo.services.ReturnService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:4200/")
public class ReturnController {
    @Autowired
    private ReturnService returnService;

    @GetMapping(value = "/returns")
    public List<Return> getAllReturns(){
        return this.returnService.getAllReturns();
    }

    @GetMapping(value = "/getReturnsByCustomer")
    public List<Return> getAllReturnsByCustomer(@RequestParam Long id){
        return this.returnService.getAllReturnsByCustomerId(id);
    }



    @PostMapping(value = "/addReturn")
    public void addReturn(@RequestBody Return returnToAdd){
        System.out.println("\n\n\n\n\n\n\n"+returnToAdd+"\n\n\n\n\n\n\n");
        this.returnService.addReturn(returnToAdd);
    }
}
