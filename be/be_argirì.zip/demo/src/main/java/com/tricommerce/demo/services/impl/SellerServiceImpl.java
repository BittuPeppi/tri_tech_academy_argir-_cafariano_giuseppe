package com.tricommerce.demo.services.impl;

import com.tricommerce.demo.models.Seller;
import com.tricommerce.demo.repositories.SellerRepository;
import com.tricommerce.demo.services.SellerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class SellerServiceImpl implements SellerService {
    @Autowired
    private SellerRepository sellerRepository;
    @Override
    public List<Seller> getAllSellers() {
        return this.sellerRepository.findAll();
    }

    @Override
    public Seller getSeller(Long id) {
        return this.sellerRepository.findById(id).orElse(null);
    }
}
