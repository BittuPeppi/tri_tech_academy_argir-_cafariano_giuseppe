package com.tricommerce.demo.services.impl;

import com.tricommerce.demo.models.Category;
import com.tricommerce.demo.repositories.CategoryRepository;
import com.tricommerce.demo.services.CategoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class CategoryServiceImpl implements CategoryService {
    @Autowired
    private CategoryRepository categoryRepository;
    @Override
    public List<Category> getAllCategories() {
        return this.categoryRepository.findAll();
    }

    @Override
    public Category getCategory(Long id) {
        return this.categoryRepository.findById(id).orElse(null);
    }

    @Override
    public void addCategory(Category category) {
        this.categoryRepository.save(category);
    }
}
