package com.tricommerce.demo.controllers;

import com.tricommerce.demo.models.CreditCard;
import com.tricommerce.demo.services.CreditCardService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
@RestController
@CrossOrigin(origins = "http://localhost:4200/")
public class CreditCardController {
    @Autowired
    private CreditCardService creditCardService;

    @GetMapping(value = "/getCreditCard")
    public CreditCard getCreditCard(@RequestParam Long id){
        return this.creditCardService.getCreditCard(id);
    }

    @PostMapping(value = "/addCreditCard")
    public void addCreditCard(@RequestBody CreditCard creditCard){
        this.creditCardService.addCreditCard(creditCard);
    }

    @PutMapping(value = "/updateCreditCard")
    public void updateCreditCard(@RequestBody CreditCard creditCard){
        this.creditCardService.updateCreditCard(creditCard);
    }
}
