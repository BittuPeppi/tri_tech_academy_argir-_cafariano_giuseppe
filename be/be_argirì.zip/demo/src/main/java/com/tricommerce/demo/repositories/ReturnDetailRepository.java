package com.tricommerce.demo.repositories;

import com.tricommerce.demo.models.OrderDetail;
import com.tricommerce.demo.models.ReturnDetail;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ReturnDetailRepository extends JpaRepository<ReturnDetail, Long> {
    @Query("SELECT MAX(r.id) FROM ReturnDetail r")
    Long getReturnMaxId();

    @Query("SELECT DISTINCT rd FROM ReturnDetail rd, Return r WHERE rd.id = r.detail AND r.customer.id = :id ORDER BY rd.id DESC")
    List<ReturnDetail> getReturnDetailByCustomerId(@Param("id") Long id);
}
