package com.tricommerce.demo.controllers;

import com.tricommerce.demo.models.Category;
import com.tricommerce.demo.models.Product;
import com.tricommerce.demo.services.CategoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:4200/")
public class CategoryController {
    @Autowired
    private CategoryService categoryService;

    @GetMapping(value = "/categories")
    public List<Category> getAllCategories(){
        return this.categoryService.getAllCategories();
    }

    @GetMapping(value = "/categories/getById")
    public Category getCategory(Long id){
        return this.categoryService.getCategory(id);
    }

    @PostMapping(value = "/categories/addCategory")
    public void addProduct(@RequestBody Category category){
        this.categoryService.addCategory(category);
    }
}
