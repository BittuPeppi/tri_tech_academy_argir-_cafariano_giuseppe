package com.tricommerce.demo.models;

import javax.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "ag_orderdetail")
public class OrderDetail {
    @Id
    private Long id;
    private LocalDate deliveryDate;
    private LocalDate orderDate;
    private String status;
    private String paymentMethod;
    private LocalDate shippingDate;

    public OrderDetail(LocalDate deliveryDate,LocalDate orderDate, String status, String paymentMethod, LocalDate shippingDate) {
        this.deliveryDate = deliveryDate;
        this.status = status;
        this.paymentMethod = paymentMethod;
        this.shippingDate = shippingDate;
        this.orderDate = orderDate;
    }
}
