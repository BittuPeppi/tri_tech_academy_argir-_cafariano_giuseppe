package com.tricommerce.demo.services;

import com.tricommerce.demo.models.Customer;

import java.util.List;

public interface CustomerService {
    List<Customer> getAllCustomers();
    Customer getCustomer(Long id);
    Customer getCustomer(String email, String password);

    Customer getCustomerEmail(String email);
    void deleteCustomer(Long id);
    void updateCustomer(Customer customer);
    void addCustomer(Customer customer);

}
