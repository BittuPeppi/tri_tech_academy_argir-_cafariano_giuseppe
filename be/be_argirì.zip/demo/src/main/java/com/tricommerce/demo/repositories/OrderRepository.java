package com.tricommerce.demo.repositories;

import com.tricommerce.demo.models.Customer;
import com.tricommerce.demo.models.Order;
import com.tricommerce.demo.models.Return;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface OrderRepository extends JpaRepository<Order, Long> {
    List<Order> findByCustomerId(Long id);
    List<Order> findByDetailId(Long id);
}
